class Mecanic extends Treballador{

    constructor(nom, cognom, antiguitat){
        super(nom, cognom, antiguitat)
        this._estudis_sup = true;
        this._sou = this._sou + (10000 * this._antiguitat);
    }

    mostrarDades(){
        return `Nom: ${this._nom}. Cognom: ${this._cognom}. Antiguitat: ${this._antiguitat}. Estudis superiors: ${this._estudis_sup}. Sou: ${this._sou} €.`;
    }
}